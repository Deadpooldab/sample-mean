var mongoose = require('mongoose');

const userSchema = mongoose.Schema({
Name : { type: String},
UserId: { type: Number}
});

const user = mongoose.model('Users', userSchema, 'Users');
module.exports = user;